using System;
using System.Collections.Generic;
using System.Linq;
using WebPrint.Models;

namespace WebPrint.Helpers
{
    public static class BarcodePrintHelper
    {
        public static string GetBarcodePrintData(BarcodePrinting config)
        {
            BarcodeConfig template = config.PrintTemplate;
            List<BarcodePrintDetail> printDetail = config.PrintDetails;
            IDictionary<int, IDictionary<string, string>> details = GetRowToPrint(printDetail, template.ConfigAttributes);
            decimal Quantity = printDetail.Sum(obj => obj.Quantity);
            decimal LoopCount = Math.Ceiling(Quantity / template.TableColumnCount);
            int Count = 1;
            string response = template.PrnContent;
            foreach (var ele in details)
            {
                if (template.TableColumnCount == 1)
                {
                    foreach (var item in ele.Value)
                    {
                        response = response.Replace(item.Key, item.Value);
                    }
                }
                else
                {
                    foreach (var item in ele.Value)
                    {
                        response = response.Replace(item.Key + Count, item.Value);
                    }
                }
                Count++;
                if (Count > template.TableColumnCount)
                {
                    LoopCount--;
                    Count = 1;
                    if (LoopCount > 0) {
                        response += template.PrnContent;
                    }
                }
            }
            return response;
        }

        public static string[] GetBarcodePrintDataArray(BarcodePrinting config)
        {
            BarcodeConfig template = config.PrintTemplate;
            List<BarcodePrintDetail> printDetail = config.PrintDetails;
            IDictionary<int, IDictionary<string, string>> details = GetRowToPrint(printDetail, template.ConfigAttributes);
            decimal Quantity = printDetail.Sum(obj => obj.Quantity);
            decimal LoopCount = Math.Ceiling(Quantity / template.TableColumnCount);
            int Count = 1;
            int index = 0;
            string[] arrresponse = new string[Convert.ToInt32(LoopCount)];
            string response = template.PrnContent;
            foreach (var ele in details)
            {
                if (template.TableColumnCount == 1)
                {
                    foreach (var item in ele.Value)
                    {
                        response = response.Replace(item.Key, item.Value);
                    }
                }
                else
                {
                    foreach (var item in ele.Value)
                    {
                        response = response.Replace(item.Key + Count, item.Value);
                    }
                }
                Count++;
                if (Count > template.TableColumnCount)
                {
                    LoopCount--;
                    Count = 1;
                    arrresponse[index] = response;
                    index++;
                    if (LoopCount > 0) {
                        response = template.PrnContent;
                    }
                }
            }
            return arrresponse;
        }

        private static IDictionary<int, IDictionary<string, string>> GetRowToPrint(List<BarcodePrintDetail> details, 
            List<BarcodeConfigAttr> Attr)
        {
            int Count = 1;
            IDictionary<int, IDictionary<string, string>> response = new Dictionary<int, IDictionary<string, string>>();
            details.ForEach(ele =>
            {
                var prodval = GetKeyValuePairs(ele, Attr);
                for (var ln = 0; ln < ele.Quantity; ln++)
                {
                    response.Add(Count, prodval);
                    Count++;
                }
            });
            return response;
        }

        private static IDictionary<string, string> GetKeyValuePairs(BarcodePrintDetail details,
            List<BarcodeConfigAttr> Attr)
        {
            IDictionary<string, string> response = new Dictionary<string, string>();
            Attr.ForEach(ele => {
                if (ele.AttributeName == "Barcode")
                {
                    response.Add("Barcode", details.Barcode);
                }
                else if (ele.AttributeName == "Product")
                {
                    response.Add("Product", details.Product);
                }
                else if (ele.AttributeName == "SellingRate")
                {
                    response.Add("SellingRate", details.SellingRate.ToString());
                }
                else if (ele.AttributeName == "Mrp")
                {
                    response.Add("Mrp", details.Mrp.ToString());
                }
                else
                {
                    var values = details.PrintAttr.Where(x => x.key.ToUpper() == ele.AttributeName.ToUpper())
                        .FirstOrDefault();
                    if (values != null) 
                    {
                        response.Add(ele.AttributeName, values.Value);
                    }
                    else 
                    {
                        response.Add(ele.AttributeName, "");
                    }
                }
            });
            return response;
        }
    }
}