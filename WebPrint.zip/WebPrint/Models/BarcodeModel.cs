using System.Collections.Generic;

namespace WebPrint.Models
{
    public class BarcodePrinting
    {
        public string TemplateName { get; set; }
        public BarcodeConfig PrintTemplate { get; set; }
        public List<BarcodePrintDetail> PrintDetails { get; set; }
    }

    public class BarcodeConfig
    {
        public string PrnContent { get; set; }
        public int TableColumnCount { get; set; }
        public List<BarcodeConfigAttr> ConfigAttributes { get; set; }
    }

    public class BarcodeConfigAttr
    {
        public string AttributeName { get; set; }
        public string AttributeValue { get; set; }
    }

    public class BarcodePrintDetail
    {
        public string Barcode { get; set; }
        public string Product { get; set; }
        public decimal Quantity { get; set; }
        public int SellingRate { get; set; }
        public int Mrp { get; set; }
        public List<barcodePrintAttr> PrintAttr { get; set; }
    }

    public class barcodePrintAttr
    {
        public string key { get; set; }
        public string Value { get; set; }
    }
}