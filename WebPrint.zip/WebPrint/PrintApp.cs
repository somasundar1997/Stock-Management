﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;
using WebPrint.Helpers;
using WebPrint.Models;

namespace WebPrint
{
    public partial class PrintApp : Form
    {
        private StreamReader streamToPrint;
        private Font printFont;
        PrinterSettings settings = new PrinterSettings();
        public PrintApp()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
            this.Visible = false;
            printername.Text = settings.PrinterName;
            trayIcon.Visible = true;
            trayIcon.ContextMenuStrip = new ContextMenuStrip();
            trayIcon.ContextMenuStrip.Items.Add("Show", null, trayIcon_DoubleClick);
            trayIcon.ContextMenuStrip.Items.Add("Hide", null, trayIcon_hide);
            trayIcon.ContextMenuStrip.Items.Add("Exit", null, Exit);
            trayIcon.DoubleClick += new EventHandler(trayIcon_DoubleClick);
            this.Hide();
            backgroundWorker1.RunWorkerAsync();
        }

        void Exit(object sender, EventArgs e)
        {
            // Hide tray icon, otherwise it will remain shown until user mouses over it
            trayIcon.Visible = false;
            Application.Exit();
        }

        private void trayIcon_DoubleClick(object Sender, EventArgs e)
        {
            // Show the form when the user double clicks on the notify icon.
            // Activate the form.
            this.Activate();
            this.Visible = true;
            // Set the WindowState to normal if the form is minimized.
            this.WindowState = FormWindowState.Normal;
            this.Show();
        }
        private void trayIcon_hide(object Sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.Hide();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            HttpListener listener = new HttpListener();
            listener.Prefixes.Add("http://localhost:7000/");
            // listener.Prefixes.Add("https://localhost:7001/");
            listener.Start();
            Console.WriteLine("===================================================");
            Console.WriteLine($"Now Listening on: http://localhost:7000");
            // Console.WriteLine($"Now Listening on: https://localhost:7001");
            Console.WriteLine("===================================================");
            while (true)
            {
                Console.WriteLine("Waiting For Request.....");
                var context = listener.GetContext();
                var request = context.Request;
                var response = context.Response;
                string Response = "Print Success";
                try
                {
                    if (request.HttpMethod == "OPTIONS")
                    {
                        response.AppendHeader("Access-Control-Allow-Headers", "*");
                        response.AppendHeader("Access-Control-Allow-Origin", "*");
                        Console.WriteLine("Preflight Request.....");
                        Response = "Preflight Success";
                    }
                    else
                    {
                        response.AppendHeader("Access-Control-Allow-Headers", "*");
                        response.AppendHeader("Access-Control-Allow-Origin", "*");
                        Console.WriteLine("Received Request.....");
                        PrinterSettings settings = new PrinterSettings();
                        Console.WriteLine($"Printer Name: {settings.PrinterName}");
                        if (request.RawUrl.ToString().ToUpper().EndsWith("PRINTBARCODE"))
                        {
                            streamToPrint = new StreamReader(request.InputStream, request.ContentEncoding);
                            string data = streamToPrint.ReadToEnd();
                            BarcodePrinting config = new BarcodePrinting();
                            config = JsonSerializer.Deserialize<BarcodePrinting>(data);
                            bool PrintOneByOne = true;
                            if (PrintOneByOne)
                            {
                                string[] resp = BarcodePrintHelper.GetBarcodePrintDataArray(config);
                                foreach (string item in resp)
                                {
                                    string PrintContent = item;
                                    byte[] PrnBuffer = Encoding.UTF8.GetBytes(PrintContent);
                                    Stream Prnstream = new MemoryStream(PrnBuffer);
                                    streamToPrint = new StreamReader(Prnstream);
                                    printFont = new Font("Arial", 10);
                                    PrintDocument pd = new PrintDocument();
                                    pd.PrintPage += new PrintPageEventHandler(this.pd_PrintPage);
                                    pd.Print();
                                    RawPrinterHelper.SendStringToPrinter(settings.PrinterName, PrintContent);
                                }
                            }
                            else
                            {
                                string PrintContent = BarcodePrintHelper.GetBarcodePrintData(config);
                                byte[] PrnBuffer = Encoding.UTF8.GetBytes(PrintContent);
                                Stream Prnstream = new MemoryStream(PrnBuffer);
                                streamToPrint = new StreamReader(Prnstream);
                                printFont = new Font("Arial", 10);
                                PrintDocument pd = new PrintDocument();
                                pd.PrintPage += new PrintPageEventHandler(this.pd_PrintPage);
                                // pd.Print();
                                RawPrinterHelper.SendStringToPrinter(settings.PrinterName, PrintContent);
                            }
                            response.StatusCode = (int)HttpStatusCode.OK;
                            Response = "Print Success";
                        }
                        else if (request.Url.ToString().ToUpper().EndsWith("PRINTDATA"))
                        {
                            streamToPrint = new StreamReader(request.InputStream, request.ContentEncoding);
                            string data = streamToPrint.ReadToEnd();//File.ReadAllText(FilePath);//streamToPrint.ReadToEnd();
                            webBrowser.DocumentText = data.ToString();
                            // webBrowser.Visible = false;
                            // webBrowser.Width = 0;
                            // webBrowser.Height = 0;
                            // webBrowser.Document.Write(data);
                            // webBrowser.ShowPrintPreviewDialog();
                            webBrowser.Print();
                            response.StatusCode = (int)HttpStatusCode.OK;
                            Response = "Print Success";
                        }
                        else
                        {
                            response.StatusCode = (int)HttpStatusCode.BadRequest;
                            Response = "Print Failure";
                        }
                    }
                }
                catch (Exception ex)
                {
                    Response = "Print Failure";
                    Console.WriteLine(ex.StackTrace);
                }
                byte[] RespBuffer = Encoding.UTF8.GetBytes(Response);
                response.ContentLength64 = RespBuffer.Length;
                System.IO.Stream output = response.OutputStream;
                output.Write(RespBuffer, 0, RespBuffer.Length);
                Console.WriteLine(Response);
                Console.WriteLine("======================================================");
                output.Close();
            }
        }

        // The PrintPage event is raised for each page to be printed.
        private void pd_PrintPage(object sender, PrintPageEventArgs ev)
        {
            float linesPerPage = 0;
            float yPos = 0;
            int count = 0;
            float leftMargin = ev.MarginBounds.Left;
            float topMargin = ev.MarginBounds.Top;
            string line = null;

            // Calculate the number of lines per page.
            linesPerPage = ev.MarginBounds.Height / printFont.GetHeight(ev.Graphics);

            // Print each line of the file.
            while (count < linesPerPage &&
               ((line = streamToPrint.ReadLine()) != null))
            {
                yPos = topMargin + (count *
                   printFont.GetHeight(ev.Graphics));
                ev.Graphics.DrawString(line, printFont, Brushes.Black,
                   leftMargin, yPos, new StringFormat());
                count++;
            }

            // If more lines exist, print another page.
            if (line != null)
                ev.HasMorePages = true;
            else
                ev.HasMorePages = false;
        }
    }
}